package debug;

import java.io.Serializable;
import java.util.ArrayList;

public class Container implements Serializable{
	
	public ArrayList<SimpleTile> map;
	public ArrayList<SimpleObject> objects;

}
