package tankmapviewer;

public interface IPathNode {
	public int getPrecisionLevel();
}
